# ScreenCast – setup

## Gradle (app/build.gradle.kts)
- minSdk 26, compileSdk/targetSdk 34+, Kotlin + Compose enabled (`buildFeatures { compose = true }`)
- Dependencies:
  - `androidx.activity:activity-compose`, `androidx.lifecycle:lifecycle-viewmodel-compose`
  - `androidx.compose:compose-bom` + `material3`
  - `org.jetbrains.kotlinx:kotlinx-coroutines-android`
- Package: `com.example.screencast` (rename in manifest + files if you change it)

## Run
1. Phone and TV on the same Wi-Fi (no AP/client isolation).
2. Build, install, tap **Scan for TVs**, pick one, tap **Start casting**, accept the system consent dialog.
3. No DLNA TV? Start casting anyway and open the shown `http://<phone-ip>:8080/stream.mjpg` in VLC,
   a browser, or a Cast custom receiver (`<img src="...">`).
4. Rotate the phone: portrait mirrors as-is; landscape with the toggle on becomes a 1920x1080 frame.

## How the 16:9 fit works
- **Resolution**: VirtualDisplay captures at the phone's real size for the current rotation (e.g. 2400x1080),
  downscaled only if the long side exceeds 2560 px.
- **Density**: DPI scales by the same factor (`dpi = nativeDpi * scale`), so Android lays out the UI exactly
  as on the phone; only pixels are fewer, never the layout.
- **Aspect ratio**: a phone at 20:9 (2.22) is wider than 16:9 (1.78). The engine center-crops the capture to
  16:9 (2400x1080 -> 1920x1080 region, 240 px trimmed per side) and draws it into a 1920x1080 frame.
  Narrower-than-16:9 sources (4:3 tablets) are trimmed top/bottom instead. No bars either way.
- **Trade-off**: filling the TV means the outer ~10% (for 20:9) of the screen is not shown. Keep critical UI
  (e.g. game HUD) away from the edges, or turn the toggle off to see everything with bars.
- **Rotation**: `OrientationEventListener` is a debounced trigger; `Display.rotation` decides the real state,
  so a rotation-locked phone is never mismatched. The existing VirtualDisplay is `resize()`d and given a new
  Surface (Android 14 forbids creating a second one from the same projection token).

## Honest limitations
- Google Cast SDK does not expose system screen mirroring to third-party apps. This build streams MJPEG over
  HTTP and uses DLNA to tell the TV to play it. For Chromecast, add the Cast SDK sender and a small custom web
  receiver that displays the URL; WebRTC/H.264 would lower latency and bandwidth (swap `MjpegServer` for a
  MediaCodec encoder).
- DLNA TVs vary: many refuse MJPEG or need DIDL metadata in `SetAVTransportURI`. Test per TV.
- MJPEG on CPU is ~15-20 fps at 1080p with noticeable latency; no audio. 3840x2160 output is supported by
  passing `tvTarget = Size(3840, 2160)` but will be slow on this CPU path.
- DRM/secure content (Netflix etc.) is blacked out by the system.
