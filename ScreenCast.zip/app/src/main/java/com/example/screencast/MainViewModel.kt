package com.example.screencast

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** Presentation state: discovered TVs, scan status, selection. */
class MainViewModel(app: Application) : AndroidViewModel(app) {
    val devices = MutableStateFlow<List<Renderer>>(emptyList())
    val scanning = MutableStateFlow(false)
    val selected = MutableStateFlow<Renderer?>(null)

    fun scan() = viewModelScope.launch {
        scanning.value = true
        devices.value = runCatching { Dlna.discover(getApplication()) }.getOrDefault(emptyList())
        scanning.value = false
    }
    fun select(r: Renderer) { selected.value = r }
}
