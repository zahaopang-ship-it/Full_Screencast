package com.example.screencast

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.*

data class Renderer(val name: String, val controlUrl: String)

/** Minimal DLNA/UPnP: SSDP discovery + AVTransport SetAVTransportURI/Play/Stop. */
object Dlna {
    private const val ST = "urn:schemas-upnp-org:device:MediaRenderer:1"
    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"

    suspend fun discover(ctx: Context, timeoutMs: Int = 4000): List<Renderer> = withContext(Dispatchers.IO) {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("ssdp").apply { setReferenceCounted(false); acquire() }
        val locations = linkedSetOf<String>()
        try {
            DatagramSocket().use { sock ->
                sock.soTimeout = 800
                val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\nST: $ST\r\n\r\n").toByteArray()
                sock.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1900))
                val end = System.currentTimeMillis() + timeoutMs
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size); sock.receive(p)
                        Regex("(?i)^location:\\s*(.+)$", RegexOption.MULTILINE)
                            .find(String(p.data, 0, p.length))?.groupValues?.get(1)?.trim()?.let(locations::add)
                    } catch (_: SocketTimeoutException) { }
                }
            }
        } finally { lock.release() }
        locations.mapNotNull { runCatching { describe(it) }.getOrNull() }
    }

    private fun describe(location: String): Renderer? {
        val xml = URL(location).readText()
        val name = Regex("<friendlyName>(.*?)</friendlyName>").find(xml)?.groupValues?.get(1) ?: "TV"
        val svc = Regex("<service>.*?</service>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
            .map { it.value }.firstOrNull { it.contains("AVTransport") } ?: return null
        val path = Regex("<controlURL>(.*?)</controlURL>").find(svc)?.groupValues?.get(1) ?: return null
        return Renderer(name, URL(URL(location), path).toString())
    }

    suspend fun play(controlUrl: String, mediaUrl: String) = withContext(Dispatchers.IO) {
        soap(controlUrl, "SetAVTransportURI",
            "<InstanceID>0</InstanceID><CurrentURI>$mediaUrl</CurrentURI><CurrentURIMetaData></CurrentURIMetaData>")
        soap(controlUrl, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>")
    }

    suspend fun stop(controlUrl: String) = withContext(Dispatchers.IO) {
        runCatching { soap(controlUrl, "Stop", "<InstanceID>0</InstanceID>") }
    }

    private fun soap(controlUrl: String, action: String, args: String) {
        val body = """<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:$action xmlns:u="$AVT">$args</u:$action></s:Body></s:Envelope>"""
        (URL(controlUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 4000; readTimeout = 6000
            setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            setRequestProperty("SOAPACTION", "\"$AVT#$action\"")
            outputStream.use { it.write(body.toByteArray()) }
            if (responseCode !in 200..299) error("SOAP $action failed: $responseCode")
            disconnect()
        }
    }
}
