package com.example.screencast

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Minimal live fragmented-MP4 writer for one H.264 track (init segment + one moof/mdat per frame).
 * This is the format browsers accept through Media Source Extensions with very low latency.
 */
class Fmp4Muxer(private val w: Int, private val h: Int) {
    var initSegment: ByteArray? = null; private set
    var codec: String? = null; private set
    private var seq = 1
    private var lastPts = -1L
    private var decodeTime = 0L
    private val TS = 90000

    /** [annexb] is the encoder's CODEC_CONFIG buffer (SPS + PPS). Returns true when the init segment is ready. */
    fun setConfig(annexb: ByteArray): Boolean {
        var sps: ByteArray? = null; var pps: ByteArray? = null
        for (n in nals(annexb)) when (n[0].toInt() and 0x1F) { 7 -> sps = n; 8 -> pps = n }
        if (sps == null || pps == null) return false
        codec = "avc1.%02X%02X%02X".format(sps[1], sps[2], sps[3])
        initSegment = buildInit(sps, pps)
        return true
    }

    fun fragment(annexb: ByteArray, ptsUs: Long, key: Boolean): ByteArray {
        val sample = ByteArrayOutputStream().also { o ->
            DataOutputStream(o).also { d -> for (n in nals(annexb)) { d.writeInt(n.size); d.write(n) } }
        }.toByteArray()
        val dur = if (lastPts < 0) 3000 else ((ptsUs - lastPts) * TS / 1_000_000).toInt().coerceIn(900, 18000)
        lastPts = ptsUs
        fun moof(off: Int) = box("moof",
            box("mfhd", bytes { writeInt(0); writeInt(seq) }),
            box("traf",
                box("tfhd", bytes { writeInt(0x020000); writeInt(1) }),      // default-base-is-moof
                box("tfdt", bytes { writeInt(0x01000000); writeLong(decodeTime) }),
                box("trun", bytes {
                    writeInt(0x000701); writeInt(1); writeInt(off)           // data offset, duration, size, flags
                    writeInt(dur); writeInt(sample.size)
                    writeInt(if (key) 0x02000000 else 0x01010000)
                })))
        val m = moof(moof(0).size + 8)
        decodeTime += dur; seq++
        return m + box("mdat", sample)
    }

    private fun buildInit(sps: ByteArray, pps: ByteArray): ByteArray {
        val ftyp = box("ftyp", bytes { writeBytes("isom"); writeInt(0x200); writeBytes("isom"); writeBytes("iso5"); writeBytes("avc1"); writeBytes("mp41") })
        val mvhd = box("mvhd", bytes {
            writeInt(0); writeInt(0); writeInt(0); writeInt(TS); writeInt(0); writeInt(0x10000)
            writeShort(0x0100); writeShort(0); writeInt(0); writeInt(0); matrix(); repeat(6) { writeInt(0) }; writeInt(2)
        })
        val tkhd = box("tkhd", bytes {
            writeInt(3); writeInt(0); writeInt(0); writeInt(1); writeInt(0); writeInt(0); writeInt(0); writeInt(0)
            writeShort(0); writeShort(0); writeShort(0); writeShort(0); matrix(); writeInt(w shl 16); writeInt(h shl 16)
        })
        val mdhd = box("mdhd", bytes { writeInt(0); writeInt(0); writeInt(0); writeInt(TS); writeInt(0); writeShort(0x55C4); writeShort(0) })
        val hdlr = box("hdlr", bytes { writeInt(0); writeInt(0); writeBytes("vide"); repeat(3) { writeInt(0) }; writeBytes("VideoHandler"); writeByte(0) })
        val vmhd = box("vmhd", bytes { writeInt(1); writeShort(0); repeat(3) { writeShort(0) } })
        val dinf = box("dinf", box("dref", bytes { writeInt(0); writeInt(1) }, box("url ", bytes { writeInt(1) })))
        val avcC = box("avcC", bytes {
            writeByte(1); writeByte(sps[1].toInt()); writeByte(sps[2].toInt()); writeByte(sps[3].toInt())
            writeByte(0xFF); writeByte(0xE1); writeShort(sps.size); write(sps); writeByte(1); writeShort(pps.size); write(pps)
        })
        val avc1 = box("avc1", bytes {
            repeat(6) { writeByte(0) }; writeShort(1); writeShort(0); writeShort(0); repeat(3) { writeInt(0) }
            writeShort(w); writeShort(h); writeInt(0x480000); writeInt(0x480000); writeInt(0); writeShort(1)
            write(ByteArray(32)); writeShort(0x18); writeShort(-1)
        }, avcC)
        val empty = bytes { writeInt(0); writeInt(0) }
        val stbl = box("stbl", box("stsd", bytes { writeInt(0); writeInt(1) }, avc1),
            box("stts", empty), box("stsc", empty), box("stsz", bytes { writeInt(0); writeInt(0); writeInt(0) }), box("stco", empty))
        val trak = box("trak", tkhd, box("mdia", mdhd, hdlr, box("minf", vmhd, dinf, stbl)))
        val mvex = box("mvex", box("trex", bytes { writeInt(0); writeInt(1); writeInt(1); writeInt(0); writeInt(0); writeInt(0) }))
        return ftyp + box("moov", mvhd, trak, mvex)
    }

    private fun DataOutputStream.matrix() {
        writeInt(0x10000); writeInt(0); writeInt(0); writeInt(0); writeInt(0x10000); writeInt(0); writeInt(0); writeInt(0); writeInt(0x40000000)
    }

    private fun bytes(f: DataOutputStream.() -> Unit): ByteArray {
        val b = ByteArrayOutputStream(); DataOutputStream(b).f(); return b.toByteArray()
    }

    private fun box(type: String, vararg c: ByteArray): ByteArray = bytes {
        writeInt(8 + c.sumOf { it.size }); writeBytes(type); c.forEach { write(it) }
    }

    /** Split an Annex-B buffer (00 00 01 / 00 00 00 01 start codes) into raw NAL units. */
    private fun nals(d: ByteArray): List<ByteArray> {
        val out = ArrayList<ByteArray>(); var start = -1; var i = 0
        fun flush(end: Int) { if (start in 0 until end) out.add(d.copyOfRange(start, end)) }
        while (i + 2 < d.size) {
            if (d[i] == 0.toByte() && d[i + 1] == 0.toByte()) {
                if (d[i + 2] == 1.toByte()) { flush(i); start = i + 3; i += 3; continue }
                if (i + 3 < d.size && d[i + 2] == 0.toByte() && d[i + 3] == 1.toByte()) { flush(i); start = i + 4; i += 4; continue }
            }
            i++
        }
        flush(d.size)
        return out
    }
}
