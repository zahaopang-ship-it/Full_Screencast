package com.example.screencast

import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.opengl.*
import android.os.Handler
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * EGL/GLES2 pass between the VirtualDisplay and the H.264 encoder.
 * It is what makes "fill the 16:9 TV" possible on the GPU: it samples only the cropped region of the
 * captured screen (srcCrop) and draws it into [dst] of a FIXED-size encoder surface.
 * Everything here must run on ONE thread (the capture HandlerThread).
 */
class GlRenderer(private val encoderSurface: Surface, private val outW: Int, private val outH: Int) {
    private var dpy = EGL14.EGL_NO_DISPLAY
    private var ctx = EGL14.EGL_NO_CONTEXT
    private var surf = EGL14.EGL_NO_SURFACE
    private var program = 0; private var texId = 0
    private var aPos = 0; private var aTex = 0; private var uMat = 0
    private val texMatrix = FloatArray(16)
    private val verts: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var dst = Rect(0, 0, outW, outH)

    lateinit var surfaceTexture: SurfaceTexture; private set
    lateinit var inputSurface: Surface; private set

    fun init(frameHandler: Handler, onFrame: () -> Unit) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2); EGL14.eglInitialize(dpy, v, 0, v, 1)
        val cfgAttr = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142 /* EGL_RECORDABLE_ANDROID */, 1, EGL14.EGL_NONE
        )
        val cfg = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfg, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        surf = EGL14.eglCreateWindowSurface(dpy, cfg[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, ctx)

        program = link(
            "attribute vec4 aPos; attribute vec2 aTex; uniform mat4 uMat; varying vec2 vTex;" +
                "void main(){ gl_Position = aPos; vTex = (uMat * vec4(aTex,0.0,1.0)).xy; }",
            "#extension GL_OES_EGL_image_external : require\n precision mediump float; varying vec2 vTex;" +
                "uniform samplerExternalOES sTex; void main(){ gl_FragColor = texture2D(sTex, vTex); }"
        )
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMat = GLES20.glGetUniformLocation(program, "uMat")

        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); texId = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        surfaceTexture = SurfaceTexture(texId)
        inputSurface = Surface(surfaceTexture)
        surfaceTexture.setOnFrameAvailableListener({ onFrame() }, frameHandler)
        setLayout(1, 1, Rect(0, 0, 1, 1), dst)
    }

    /** srcCrop is in capture pixels (top-left origin); dst is in output pixels (top-left origin). */
    fun setLayout(capW: Int, capH: Int, srcCrop: Rect, dstRect: Rect) {
        dst = dstRect
        val u0 = srcCrop.left.toFloat() / capW; val u1 = srcCrop.right.toFloat() / capW
        val v0 = 1f - srcCrop.bottom.toFloat() / capH; val v1 = 1f - srcCrop.top.toFloat() / capH
        verts.clear()
        verts.put(floatArrayOf(
            -1f, -1f, u0, v0,
             1f, -1f, u1, v0,
            -1f,  1f, u0, v1,
             1f,  1f, u1, v1))
        verts.position(0)
    }

    fun draw() {
        surfaceTexture.updateTexImage()
        surfaceTexture.getTransformMatrix(texMatrix)
        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glViewport(dst.left, outH - dst.bottom, dst.width(), dst.height()) // GL origin = bottom-left
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniformMatrix4fv(uMat, 1, false, texMatrix, 0)
        verts.position(0); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, verts)
        verts.position(2); GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, verts)
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        EGLExt.eglPresentationTimeANDROID(dpy, surf, System.nanoTime())
        EGL14.eglSwapBuffers(dpy, surf)
    }

    fun release() {
        runCatching { surfaceTexture.release(); inputSurface.release() }
        if (dpy != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf); EGL14.eglDestroyContext(dpy, ctx); EGL14.eglTerminate(dpy)
        }
        dpy = EGL14.EGL_NO_DISPLAY
    }

    private fun link(vs: String, fs: String): Int {
        fun sh(type: Int, src: String) = GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
        }
        return GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, sh(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(it, sh(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(it)
        }
    }
}
