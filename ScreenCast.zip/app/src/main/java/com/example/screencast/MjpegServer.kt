package com.example.screencast

import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

/**
 * Tiny multipart/x-mixed-replace (MJPEG) server. Any GET gets the live stream.
 * Works in browsers, VLC, many DLNA TVs, and a Cast custom receiver (<img src=...>).
 */
class MjpegServer(private val port: Int) {
    private var server: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<Socket>()
    @Volatile private var running = false

    fun start() {
        running = true
        thread(name = "mjpeg-accept", isDaemon = true) {
            try {
                server = ServerSocket(port)
                while (running) {
                    val s = server!!.accept()
                    s.soTimeout = 3000; s.tcpNoDelay = true
                    thread(isDaemon = true) { handshake(s) }
                }
            } catch (_: Exception) { /* closed */ }
        }
    }

    private fun handshake(s: Socket) {
        try {
            // Drain the HTTP request headers.
            val ins = s.getInputStream(); var last4 = 0
            while (true) { val b = ins.read(); if (b < 0) return; last4 = (last4 shl 8) or b
                if (last4 == 0x0D0A0D0A) break }
            s.getOutputStream().apply {
                write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
                flush()
            }
            clients.add(s)
        } catch (_: Exception) { runCatching { s.close() } }
    }

    /** Called from the frame thread. Slow/dead clients are dropped (3 s write timeout). */
    fun push(jpeg: ByteArray, len: Int) {
        if (clients.isEmpty()) return
        val head = "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: $len\r\n\r\n".toByteArray()
        for (c in clients) {
            try {
                val o: OutputStream = c.getOutputStream()
                o.write(head); o.write(jpeg, 0, len); o.write("\r\n".toByteArray()); o.flush()
            } catch (_: Exception) { clients.remove(c); runCatching { c.close() } }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        clients.forEach { runCatching { it.close() } }; clients.clear()
    }
}
