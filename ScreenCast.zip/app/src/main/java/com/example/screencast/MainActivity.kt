package com.example.screencast

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    /** Opens the system cast screen; falls back to wireless settings. Apps cannot start Miracast themselves. */
    private fun openSystemCast() {
        val tries = listOf(Intent(Settings.ACTION_CAST_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        for (i in tries) { try { startActivity(i); break } catch (_: Exception) { } }
        Toast.makeText(this, "Choose your TV, or use the Screencast tile in quick settings", Toast.LENGTH_LONG).show()
    }

    @Composable
    private fun Screen() {
        val devices by vm.devices.collectAsState()
        val scanning by vm.scanning.collectAsState()
        val selected by vm.selected.collectAsState()
        val running by StreamState.running.collectAsState()
        val auto by StreamState.autoFullscreen.collectAsState()
        val url by StreamState.streamUrl.collectAsState()

        // MediaProjection consent dialog result -> hand token to the foreground service.
        val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.let { MediaProjectionService.start(this, r.resultCode, it, selected?.controlUrl) }
        }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            consent.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        }

        Column(Modifier.fillMaxSize().padding(16.dp).systemBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ScreenCast", style = MaterialTheme.typography.headlineMedium)

            // PRIMARY: the phone's built-in Screencast (Miracast / Wi-Fi Display). Fast, handled by the system.
            Button(onClick = { openSystemCast() }, Modifier.fillMaxWidth()) { Text("Screencast (system, fast)") }
            Text("Opens your phone's cast screen. Pick your TV there. Rotation is handled by the system.",
                style = MaterialTheme.typography.bodySmall)
            HorizontalDivider()
            Text("Fast H.264 stream (open the link in the TV browser)", style = MaterialTheme.typography.titleSmall)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto Fullscreen on Landscape (browser stream only)", Modifier.weight(1f))
                Switch(auto, { StreamState.autoFullscreen.value = it })
            }

            Button(onClick = { vm.scan() }, enabled = !scanning && !running) {
                Text(if (scanning) "Scanning…" else "Scan for TVs (DLNA)")
            }

            LazyColumn(Modifier.weight(1f)) {
                items(devices) { d ->
                    ListItem(
                        headlineContent = { Text(d.name) },
                        leadingContent = { RadioButton(selected == d, null) },
                        modifier = Modifier.clickable { vm.select(d) }
                    )
                }
            }

            url?.let { Text("Open this on the TV browser (same Wi-Fi):\n$it", style = MaterialTheme.typography.bodySmall) }

            if (running) {
                Button(onClick = { MediaProjectionService.stop(this@MainActivity) }, Modifier.fillMaxWidth()) { Text("Stop casting") }
            } else {
                // A TV is optional: without one you still get the URL for a Cast receiver / VLC.
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else consent.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
                }, Modifier.fillMaxWidth()) { Text("Start casting") }
            }
        }
    }
}
