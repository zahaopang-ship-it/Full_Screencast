package com.example.screencast

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        val devices by vm.devices.collectAsState()
        val scanning by vm.scanning.collectAsState()
        val selected by vm.selected.collectAsState()
        val running by StreamState.running.collectAsState()
        val auto by StreamState.autoFullscreen.collectAsState()
        val url by StreamState.streamUrl.collectAsState()

        // MediaProjection consent dialog result -> hand token to the foreground service.
        val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.let { MediaProjectionService.start(this, r.resultCode, it, selected?.controlUrl) }
        }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            consent.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        }

        Column(Modifier.fillMaxSize().padding(16.dp).systemBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ScreenCast", style = MaterialTheme.typography.headlineMedium)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Auto Fullscreen on Landscape", Modifier.weight(1f))
                Switch(auto, { StreamState.autoFullscreen.value = it })
            }

            Button(onClick = { vm.scan() }, enabled = !scanning && !running) {
                Text(if (scanning) "Scanning…" else "Scan for TVs (DLNA)")
            }

            LazyColumn(Modifier.weight(1f)) {
                items(devices) { d ->
                    ListItem(
                        headlineContent = { Text(d.name) },
                        leadingContent = { RadioButton(selected == d, null) },
                        modifier = Modifier.clickable { vm.select(d) }
                    )
                }
            }

            url?.let { Text("Stream URL (open on any player / Cast receiver):\n$it", style = MaterialTheme.typography.bodySmall) }

            if (running) {
                Button(onClick = { MediaProjectionService.stop(this@MainActivity) }, Modifier.fillMaxWidth()) { Text("Stop casting") }
            } else {
                // A TV is optional: without one you still get the URL for a Cast receiver / VLC.
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else consent.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
                }, Modifier.fillMaxWidth()) { Text("Start casting") }
            }
        }
    }
}
