package com.example.screencast

import android.Manifest
import android.media.projection.MediaProjectionManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val IosBlue = Color(0xFF0A84FF)
private val IosGreen = Color(0xFF34C759)
private val IosRed = Color(0xFFFF3B30)

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { Screen() } }
    }

    /** The phone's built-in cast screen. Apps cannot start Miracast themselves. */
    private fun openSystemCast() {
        val tries = listOf(Intent(Settings.ACTION_CAST_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        for (i in tries) { try { startActivity(i); break } catch (_: Exception) { } }
        Toast.makeText(this, "Choose your TV, or use the Screencast tile in quick settings", Toast.LENGTH_LONG).show()
    }

    @Composable
    private fun Screen() {
        val devices by vm.devices.collectAsState()
        val scanning by vm.scanning.collectAsState()
        val selected by vm.selected.collectAsState()
        val running by StreamState.running.collectAsState()
        val auto by StreamState.autoFullscreen.collectAsState()
        val url by StreamState.streamUrl.collectAsState()
        val clipboard = LocalClipboardManager.current
        val cs = MaterialTheme.colorScheme

        val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.let { MediaProjectionService.start(this, r.resultCode, it, selected?.controlUrl) }
        }
        val askConsent = {
            consent.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askConsent() }

        Column(
            Modifier.fillMaxSize().background(cs.background).systemBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(20.dp))
            Text("ScreenCast", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)
            Text("Mirror your phone to the TV", fontSize = 16.sp, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))

            // ---- Status ----
            Group {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    val chip by animateColorAsState(if (running) IosGreen else IosBlue.copy(alpha = 0.14f), label = "chip")
                    Box(Modifier.size(52.dp).clip(CircleShape).background(chip), contentAlignment = Alignment.Center) {
                        CastGlyph(if (running) Color.White else IosBlue)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(if (running) "Casting" else "Ready", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                        Text(if (running) "Your screen is live on the network" else "Not casting right now",
                            fontSize = 14.sp, color = cs.onSurfaceVariant)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            val btnColor by animateColorAsState(if (running) IosRed else IosBlue, label = "btn")
            Button(
                onClick = {
                    if (running) MediaProjectionService.stop(this@MainActivity)
                    else if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else askConsent()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = btnColor, contentColor = Color.White)
            ) { Text(if (running) "Stop casting" else "Start casting", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }

            // ---- Quick cast ----
            SectionHeader("Quick cast")
            Group {
                Row(
                    Modifier.fillMaxWidth().clickable { openSystemCast() }.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("System Screencast", fontSize = 17.sp, color = cs.onSurface)
                        Text("Fast · built into your phone", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                    Text("›", fontSize = 26.sp, color = cs.onSurfaceVariant)
                }
            }

            // ---- Display ----
            SectionHeader("Display")
            Group {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Fill TV in landscape", fontSize = 17.sp, color = cs.onSurface)
                        Text("Browser stream only", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                    Switch(
                        checked = auto, onCheckedChange = { StreamState.autoFullscreen.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = IosGreen, checkedBorderColor = Color.Transparent,
                            uncheckedThumbColor = Color.White, uncheckedTrackColor = cs.outlineVariant, uncheckedBorderColor = Color.Transparent
                        )
                    )
                }
            }

            // ---- Browser stream ----
            SectionHeader("TV browser stream")
            Group {
                if (url != null) {
                    Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Open on the TV browser", fontSize = 13.sp, color = cs.onSurfaceVariant)
                            Text(url ?: "", fontSize = 17.sp, color = IosBlue)
                        }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(url ?: ""))
                            Toast.makeText(this@MainActivity, "Link copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy", fontSize = 16.sp, color = IosBlue) }
                    }
                } else {
                    Text("Start casting to get a link for the TV's browser.", fontSize = 15.sp,
                        color = cs.onSurfaceVariant, modifier = Modifier.padding(16.dp))
                }
            }

            // ---- Smart TVs ----
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.Bottom) {
                SectionHeader("Smart TVs on Wi-Fi", Modifier.weight(1f))
                TextButton(onClick = { vm.scan() }, enabled = !scanning && !running) {
                    Text(if (scanning) "Scanning…" else "Scan", fontSize = 16.sp, color = if (!scanning && !running) IosBlue else cs.onSurfaceVariant)
                }
            }
            Group {
                if (devices.isEmpty()) {
                    Text(if (scanning) "Looking for TVs…" else "No TVs found. Tap Scan.", fontSize = 15.sp,
                        color = cs.onSurfaceVariant, modifier = Modifier.padding(16.dp))
                } else {
                    devices.forEachIndexed { i, d ->
                        if (i > 0) RowDivider()
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.select(d) }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(d.name, fontSize = 17.sp, color = cs.onSurface, modifier = Modifier.weight(1f))
                            if (selected == d) Text("✓", fontSize = 20.sp, color = IosBlue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val colors = if (dark) darkColorScheme(
        primary = IosBlue, background = Color.Black, surface = Color(0xFF1C1C1E),
        onBackground = Color.White, onSurface = Color.White,
        onSurfaceVariant = Color(0xFF8E8E93), outlineVariant = Color(0xFF39393D)
    ) else lightColorScheme(
        primary = Color(0xFF007AFF), background = Color(0xFFF2F2F7), surface = Color.White,
        onBackground = Color.Black, onSurface = Color.Black,
        onSurfaceVariant = Color(0xFF8E8E93), outlineVariant = Color(0xFFD1D1D6)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

/** iOS "inset grouped" card: soft 18dp corners, no shadow. */
@Composable
private fun Group(content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(content = content)
    }
}

@Composable
private fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), modifier = modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp),
        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun RowDivider() = HorizontalDivider(
    modifier = Modifier.padding(start = 16.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant
)

/** Same glyph as the app icon: a TV with cast waves. */
@Composable
private fun CastGlyph(color: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val w = size.width; val h = size.height; val sw = w * 0.09f
        drawRoundRect(color, Offset(w * 0.04f, h * 0.16f), Size(w * 0.92f, h * 0.62f), CornerRadius(w * 0.14f), style = Stroke(sw))
        val c = Offset(w * 0.22f, h * 0.62f)
        drawCircle(color, radius = sw * 0.8f, center = c)
        for (r in listOf(w * 0.17f, w * 0.31f)) {
            drawArc(color, 270f, 90f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
        }
        drawLine(color, Offset(w * 0.36f, h * 0.9f), Offset(w * 0.64f, h * 0.9f), sw, StrokeCap.Round)
    }
}
