package com.example.screencast

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Display
import android.view.OrientationEventListener
import android.view.Surface
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.NetworkInterface

/** Shared, observable state for the UI. */
object StreamState {
    val autoFullscreen = MutableStateFlow(true)
    val running = MutableStateFlow(false)
    val streamUrl = MutableStateFlow<String?>(null)
}

/**
 * Pipeline:  screen -> VirtualDisplay -> SurfaceTexture -> GL (crop/fit) -> H.264 encoder (fixed 1920x1080)
 *            -> fragmented MP4 -> HTTP -> TV browser (MSE).
 * The encoder resolution NEVER changes, so TVs/browsers never see a resolution switch on rotation.
 * Android 14+: one createVirtualDisplay per projection token, so rotation uses resize().
 */
class MediaProjectionService : Service() {

    private val worker = HandlerThread("capture").apply { start() }
    private val handler by lazy { Handler(worker.looper) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var scaler: AspectScaleManager? = null
    private var spec: FrameSpec? = null
    private var controlUrl: String? = null
    private var orientationListener: OrientationEventListener? = null
    private var autoJob: Job? = null

    private var encoder: MediaCodec? = null
    private var renderer: GlRenderer? = null
    private val muxer = Fmp4Muxer(OUT_W, OUT_H)
    private val server = LiveServer(PORT) { requestKeyFrame() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (projection == null) startCasting(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCasting(intent: Intent) {
        startForegroundCompat() // must come before MediaProjection on API 34+

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        controlUrl = intent.getStringExtra(EXTRA_CONTROL_URL)
        if (data == null || code != Activity.RESULT_OK) { stopSelf(); return }

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data).apply {
            registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
        }

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        scaler = AspectScaleManager(
            nativeShort = minOf(dm.widthPixels, dm.heightPixels),
            nativeLong = maxOf(dm.widthPixels, dm.heightPixels),
            nativeDpi = dm.densityDpi
        )

        handler.post { startPipeline() }

        orientationListener = object : OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                handler.removeCallbacks(refreshRunnable)
                handler.postDelayed(refreshRunnable, 350) // debounce; Display.rotation is the truth
            }
        }.also { if (it.canDetectOrientation()) it.enable() }

        autoJob = scope.launch { StreamState.autoFullscreen.collect { handler.post { refresh() } } }

        val ip = localIp()
        StreamState.streamUrl.value = "http://$ip:$PORT/"
        StreamState.running.value = true
        controlUrl?.let { c -> scope.launch { runCatching { Dlna.play(c, "http://$ip:$PORT/live.mp4") } } }
    }

    /** Runs on the capture thread: encoder first (gives the input surface), then GL, then the VirtualDisplay. */
    private fun startPipeline() {
        server.start()
        val encSurface = startEncoder()
        renderer = GlRenderer(encSurface, OUT_W, OUT_H).also { r ->
            r.init(handler) { runCatching { r.draw() } }
        }
        refresh()
    }

    private fun startEncoder(): Surface {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, OUT_W, OUT_H).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setLong("repeat-previous-frame-after", 100_000L) // keep emitting frames when the screen is static
            if (Build.VERSION.SDK_INT >= 23) setInteger(MediaFormat.KEY_PRIORITY, 0) // real-time
            if (Build.VERSION.SDK_INT >= 29) setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            if (Build.VERSION.SDK_INT >= 30) setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.setCallback(object : MediaCodec.Callback() {
            override fun onInputBufferAvailable(c: MediaCodec, i: Int) {}
            override fun onOutputFormatChanged(c: MediaCodec, f: MediaFormat) {}
            override fun onError(c: MediaCodec, e: MediaCodec.CodecException) { stopSelf() }
            override fun onOutputBufferAvailable(c: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
                val buf = c.getOutputBuffer(index)
                val bytes = if (buf != null && info.size > 0) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    ByteArray(info.size).also { buf.get(it) }
                } else null
                c.releaseOutputBuffer(index, false)
                if (bytes == null) return
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                    if (muxer.setConfig(bytes)) { server.codec = muxer.codec!!; server.initSegment = muxer.initSegment }
                } else {
                    val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                    server.push(muxer.fragment(bytes, info.presentationTimeUs, key), key)
                }
            }
        }, handler)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        encoder = enc
        return surface
    }

    private fun requestKeyFrame() {
        runCatching {
            encoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        }
    }

    private val refreshRunnable = Runnable { refresh() }

    /** Recompute crop/fit for the current real rotation and resize the VirtualDisplay if needed. */
    private fun refresh() {
        val proj = projection ?: return
        val r = renderer ?: return
        val scaler = scaler ?: return
        val rot = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation
        val landscape = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val s = scaler.compute(landscape, StreamState.autoFullscreen.value)
        if (s == spec) return
        spec = s

        r.surfaceTexture.setDefaultBufferSize(s.captureW, s.captureH)
        r.setLayout(s.captureW, s.captureH, s.srcCrop, s.dst)
        if (display == null) {
            display = proj.createVirtualDisplay(
                "ScreenCast", s.captureW, s.captureH, s.captureDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.inputSurface, null, handler
            )
        } else {
            display!!.resize(s.captureW, s.captureH, s.captureDpi)
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Screen casting", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, MediaProjectionService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Casting your screen")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun localIp(): String =
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress && it.address.size == 4 }
            ?.hostAddress ?: "0.0.0.0"

    override fun onDestroy() {
        controlUrl?.let { runBlocking(Dispatchers.IO) { withTimeoutOrNull(1500) { Dlna.stop(it) } } }
        autoJob?.cancel(); scope.cancel()
        orientationListener?.disable()
        runCatching { display?.release() }
        runCatching { encoder?.stop(); encoder?.release() }
        runCatching { handler.post { renderer?.release() } }
        runCatching { projection?.stop() }
        server.stop(); worker.quitSafely()
        StreamState.running.value = false; StreamState.streamUrl.value = null
        super.onDestroy()
    }

    companion object {
        const val PORT = 8080
        const val OUT_W = 1920; const val OUT_H = 1080
        private const val CH = "cast"
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        const val EXTRA_RESULT_CODE = "rc"; const val EXTRA_DATA = "data"; const val EXTRA_CONTROL_URL = "ctl"

        fun start(ctx: Context, resultCode: Int, data: Intent, controlUrl: String?) =
            ctx.startForegroundService(Intent(ctx, MediaProjectionService::class.java)
                .setAction(ACTION_START).putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data).putExtra(EXTRA_CONTROL_URL, controlUrl))

        fun stop(ctx: Context) = ctx.startService(Intent(ctx, MediaProjectionService::class.java).setAction(ACTION_STOP))
    }
}
