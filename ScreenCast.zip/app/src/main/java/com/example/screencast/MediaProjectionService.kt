package com.example.screencast

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Display
import android.view.OrientationEventListener
import android.view.Surface
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream
import java.net.NetworkInterface

/** Shared, observable state for the UI (kept trivial on purpose). */
object StreamState {
    val autoFullscreen = MutableStateFlow(true)
    val running = MutableStateFlow(false)
    val streamUrl = MutableStateFlow<String?>(null)
}

/**
 * Owns MediaProjection + VirtualDisplay for the whole cast session.
 * NOTE (Android 14+): a MediaProjection token allows ONE createVirtualDisplay() call, so on rotation
 * we RESIZE the existing VirtualDisplay and swap its Surface instead of recreating it.
 */
class MediaProjectionService : Service() {

    private val worker = HandlerThread("capture").apply { start() }
    private val handler by lazy { Handler(worker.looper) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val server = MjpegServer(PORT)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var scaler: AspectScaleManager? = null
    private var spec: FrameSpec? = null
    private var controlUrl: String? = null
    private var orientationListener: OrientationEventListener? = null
    private var autoJob: Job? = null

    // Reused buffers (avoid GC churn at ~20 fps)
    private var srcBmp: Bitmap? = null
    private var outBmp: Bitmap? = null
    private val jpeg = ByteArrayOutputStream(1 shl 19)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private var lastFrameNs = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (projection == null) startCasting(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCasting(intent: Intent) {
        // 1. Promote to foreground BEFORE touching MediaProjection (hard requirement on API 34+).
        startForegroundCompat()

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        controlUrl = intent.getStringExtra(EXTRA_CONTROL_URL)
        if (data == null || code != Activity.RESULT_OK) { stopSelf(); return }

        // 2. Projection. A callback MUST be registered before createVirtualDisplay (API 34+).
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).apply {
            registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }   // user revoked via status bar chip
            }, handler)
        }

        // 3. Native display metrics -> scaling engine.
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        scaler = AspectScaleManager(
            nativeShort = minOf(dm.widthPixels, dm.heightPixels),
            nativeLong = maxOf(dm.widthPixels, dm.heightPixels),
            nativeDpi = dm.densityDpi
        )

        server.start()
        handler.post { refresh() }

        // 4. Rotation: sensor is only the TRIGGER; Display.rotation is the truth
        //    (respects the user's rotation lock, so we never mismatch the real screen).
        orientationListener = object : OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                handler.removeCallbacks(refreshRunnable)
                handler.postDelayed(refreshRunnable, 350) // debounce + let system finish rotating
            }
        }.also { if (it.canDetectOrientation()) it.enable() }

        // 4b. Reliable triggers: the system tells us whenever the display changes (rotation by a game,
        //     by the sensor, or by the user), plus a cheap 1 s poll as a safety net.
        displayListener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(id: Int) {}
            override fun onDisplayRemoved(id: Int) {}
            override fun onDisplayChanged(id: Int) {
                if (id != Display.DEFAULT_DISPLAY) return
                handler.removeCallbacks(refreshRunnable)
                handler.postDelayed(refreshRunnable, 150)
            }
        }
        getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
        handler.postDelayed(pollRunnable, 1000)

        // 5. Toggle "Auto Fullscreen on Landscape" applies live.
        autoJob = scope.launch { StreamState.autoFullscreen.collect { handler.post { refresh() } } }

        // 6. Tell the TV (DLNA) to pull our stream.
        val url = "http://${localIp()}:$PORT/stream.mjpg"
        StreamState.streamUrl.value = url
        StreamState.running.value = true
        controlUrl?.let { c -> scope.launch { runCatching { Dlna.play(c, url) } } }
    }

    private val refreshRunnable = Runnable { refresh() }
    private val pollRunnable = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }
    private var displayListener: DisplayManager.DisplayListener? = null

    /** Recompute the FrameSpec for the current rotation and (re)configure the VirtualDisplay. */
    private fun refresh() {
        val proj = projection ?: return
        val scaler = scaler ?: return
        // Truth = the real current size of the default display (works for games that force landscape).
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val landscape = dm.widthPixels > dm.heightPixels
        val s = scaler.compute(landscape, StreamState.autoFullscreen.value)
        if (s == spec) return
        spec = s

        val newReader = ImageReader.newInstance(s.captureW, s.captureH, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ onFrame(it) }, handler)
        }
        if (display == null) {
            display = proj.createVirtualDisplay(
                "ScreenCast", s.captureW, s.captureH, s.captureDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, newReader.surface, null, handler
            )
        } else {
            display!!.resize(s.captureW, s.captureH, s.captureDpi) // new size + density
            display!!.surface = newReader.surface                  // new buffer size
        }
        reader?.close(); reader = newReader
        srcBmp = null; outBmp = null                               // force re-alloc for new size
    }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val s = spec ?: return
            val now = System.nanoTime()
            if (now - lastFrameNs < MIN_FRAME_NS) return           // cap ~20 fps
            if (img.width != s.captureW || img.height != s.captureH) return // stale frame mid-resize
            lastFrameNs = now

            val p = img.planes[0]
            val paddedW = p.rowStride / p.pixelStride              // rows can be padded
            val src = srcBmp?.takeIf { it.width == paddedW } ?: Bitmap.createBitmap(paddedW, img.height, Bitmap.Config.ARGB_8888).also { srcBmp = it }
            src.copyPixelsFromBuffer(p.buffer)

            val out = outBmp ?: Bitmap.createBitmap(s.outW, s.outH, Bitmap.Config.ARGB_8888)
                .also { it.eraseColor(Color.BLACK); outBmp = it } // black bars stay black
            // Crop (fill) + scale into the TV-shaped frame in a single draw.
            Canvas(out).drawBitmap(src, s.srcCrop, s.dst, paint)

            jpeg.reset()
            out.compress(Bitmap.CompressFormat.JPEG, 70, jpeg)
            server.push(jpeg.toByteArray(), jpeg.size())
        } finally { img.close() }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Screen casting", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, MediaProjectionService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Casting your screen")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Stop", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun localIp(): String =
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress && it.address.size == 4 }
            ?.hostAddress ?: "0.0.0.0"

    override fun onDestroy() {
        controlUrl?.let { runBlocking(Dispatchers.IO) { withTimeoutOrNull(1500) { Dlna.stop(it) } } }
        autoJob?.cancel(); scope.cancel()
        orientationListener?.disable()
        displayListener?.let { getSystemService(DisplayManager::class.java).unregisterDisplayListener(it) }
        handler.removeCallbacksAndMessages(null)
        display?.release(); reader?.close()
        runCatching { projection?.stop() }
        server.stop(); worker.quitSafely()
        StreamState.running.value = false; StreamState.streamUrl.value = null
        super.onDestroy()
    }

    companion object {
        const val PORT = 8080
        private const val CH = "cast"
        private const val MIN_FRAME_NS = 50_000_000L
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        const val EXTRA_RESULT_CODE = "rc"; const val EXTRA_DATA = "data"; const val EXTRA_CONTROL_URL = "ctl"

        fun start(ctx: Context, resultCode: Int, data: Intent, controlUrl: String?) =
            ctx.startForegroundService(Intent(ctx, MediaProjectionService::class.java)
                .setAction(ACTION_START).putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data).putExtra(EXTRA_CONTROL_URL, controlUrl))

        fun stop(ctx: Context) = ctx.startService(Intent(ctx, MediaProjectionService::class.java).setAction(ACTION_STOP))
    }
}
