package com.example.screencast

import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Tiny HTTP server:  GET /          -> full-screen player page (MediaSource Extensions, live-edge catch-up)
 *                    GET /live.mp4  -> endless fragmented MP4 (init segment, then frames from a keyframe)
 * Each viewer has its own queue + writer thread, so a slow TV can never stall the encoder.
 */
class LiveServer(private val port: Int, private val requestKeyFrame: () -> Unit) {
    @Volatile var initSegment: ByteArray? = null
    @Volatile var codec: String = "avc1.640028"

    private class Client(val sock: Socket) {
        val q = LinkedBlockingQueue<ByteArray>(90)
        @Volatile var needKey = true
    }

    private val clients = CopyOnWriteArrayList<Client>()
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start() {
        running = true
        thread(name = "live-accept", isDaemon = true) {
            try {
                server = ServerSocket(port)
                while (running) { val s = server!!.accept(); thread(isDaemon = true) { handle(s) } }
            } catch (_: Exception) { }
        }
    }

    private fun handle(s: Socket) {
        var c: Client? = null
        try {
            s.tcpNoDelay = true
            val br = s.getInputStream().bufferedReader()
            val path = br.readLine()?.split(" ")?.getOrNull(1) ?: return
            while (br.readLine()?.isNotEmpty() == true) { }
            val out = s.getOutputStream()
            if (path.startsWith("/live.mp4")) {
                var waited = 0
                while (initSegment == null && waited++ < 50) Thread.sleep(100)
                val init = initSegment ?: return
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: video/mp4\r\nCache-Control: no-cache\r\n" +
                        "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(init); out.flush()
                c = Client(s).also { clients.add(it) }
                requestKeyFrame()
                while (running) {
                    val b = c.q.poll(2, TimeUnit.SECONDS) ?: continue
                    out.write(b); out.flush()
                }
            } else {
                val body = page(codec).toByteArray()
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(body); out.flush()
            }
        } catch (_: Exception) {
        } finally {
            c?.let { clients.remove(it) }
            runCatching { s.close() }
        }
    }

    /** Called from the encoder callback thread for every encoded frame. */
    fun push(fragment: ByteArray, key: Boolean) {
        for (c in clients) {
            if (c.needKey) { if (!key) continue; c.needKey = false }
            if (!c.q.offer(fragment)) { c.q.clear(); c.needKey = true; requestKeyFrame() } // too slow: resync
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        clients.forEach { runCatching { it.sock.close() } }; clients.clear()
    }

    private fun page(codec: String) = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}video{width:100%;height:100%;object-fit:contain;background:#000}</style>
</head><body><video id="v" autoplay muted playsinline></video><script>
var v=document.getElementById('v'),ms=new MediaSource(),q=[],sb=null;
v.src=URL.createObjectURL(ms);
function pump(){if(sb&&!sb.updating&&q.length){try{sb.appendBuffer(q.shift());}catch(e){}}}
function trim(){try{if(sb.buffered.length){var e=sb.buffered.end(sb.buffered.length-1);
 if(e-v.currentTime>0.5){v.currentTime=e-0.1;}
 if(!sb.updating&&v.currentTime-sb.buffered.start(0)>8){sb.remove(0,v.currentTime-4);}}}catch(x){}}
ms.addEventListener('sourceopen',function(){
 sb=ms.addSourceBuffer('video/mp4; codecs="$codec"');sb.mode='sequence';
 sb.addEventListener('updateend',function(){pump();trim();});
 fetch('/live.mp4').then(function(r){var rd=r.body.getReader();
  (function read(){rd.read().then(function(x){if(x.done){location.reload();return;}
   q.push(x.value);pump();v.play().catch(function(){});read();});})();
 }).catch(function(){setTimeout(function(){location.reload();},2000);});
});
setInterval(trim,500);
</script></body></html>"""
}
